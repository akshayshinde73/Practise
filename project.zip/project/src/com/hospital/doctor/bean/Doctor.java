package com.hospital.doctor.bean;

//AKSHAY SHINDE
public class Doctor {

	long id;
	String name;
	String specialization;
	
	public Doctor(long id ,String name, String specialization) {
		super();
		this.id=id;
		this.name = name;
		this.specialization = specialization;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSpecialization() {
		return specialization;
	}
	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}

	@Override
	public String toString() {
		return "Doctor [id=" + id + ", name=" + name + ", specialization=" + specialization + "]";
	}

	
	
}
