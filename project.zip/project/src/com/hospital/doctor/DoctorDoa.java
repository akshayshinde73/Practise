package com.hospital.doctor;


//AKSHAY SHINDE
import java.util.List;

import com.hospital.doctor.bean.Doctor;

public class DoctorDoa implements DoctorInterface{

	//AKSHAY SHINDE
	
	public long addDoctor(String name, String speciality)  {
		// TODO Auto-generated method stub
		long id=0;
		try {
			java.sql.Connection connection=com.hospital.doctor.DBUtil.getConnection();
			java.sql.Statement statement=connection.createStatement();
			String sql="select max(id) from tempdoctor";
			java.sql.ResultSet result=statement.executeQuery(sql);	
			if(result.next()) {
				id=result.getLong(1);			
			}
			++id;
			sql="insert into tempdoctor values(?,?,?)";
			java.sql.PreparedStatement preparedStatement=connection.prepareStatement(sql);
			
			preparedStatement.setLong(1,id);
			preparedStatement.setString(2,name);
			preparedStatement.setString(3,speciality);

			preparedStatement.executeUpdate();
			connection.commit();
			connection.close();
			
		}catch(Exception e) {
			System.err.println("invalid");
		}
			
		return id ;
	}

	@Override
	public Doctor showDoctorById(long id) {
		// TODO Auto-generated method stub
          com.hospital.doctor.bean.Doctor  doctor=null;	
	    try {
			java.sql.Connection connection=com.hospital.doctor.DBUtil.getConnection();
			
			String sql="select * from tempdoctor where id=?";
			java.sql.PreparedStatement preparedStatement=connection.prepareStatement(sql);
            preparedStatement.setLong(1, id);
            
           java.sql.ResultSet result=preparedStatement.executeQuery();
           if(result.next()) {
			Long idDoctor=result.getLong("id");
			String name=result.getString("name");
			String specification=result.getString("speciality");
			connection.commit();
			connection.close();
			
			 doctor=new com.hospital.doctor.bean.Doctor(idDoctor,name,specification);
           }
	    }catch(Exception e) {
	    	System.err.println("invalid");
	    }
	
	
	return doctor;
	}

	@Override
	public List<com.hospital.doctor.bean.Doctor> showAllDoctor() {
		
		
		java.util.List<com.hospital.doctor.bean.Doctor> doctors=new java.util.ArrayList<>();

		try {
			java.sql.Connection connection=com.hospital.doctor.DBUtil.getConnection();
			//java.sql.Statement statement=connection.createStatement();
			String sql="select * from tempdoctor";
			
			java.sql.PreparedStatement preparedStatement=connection.prepareStatement(sql);
			java.sql.ResultSet result=preparedStatement.executeQuery(sql);

		//	sql="insert into employee values("+id +","+name ","+salary    )
			while(result.next()) {
				long   id=result.getLong("id");
				String name=result.getString("name");
				String specification=result.getString("speciality");
				com.hospital.doctor.bean.Doctor doctor= new com.hospital.doctor.bean.Doctor(id, name, specification);
           doctors.add(doctor);
			}
			connection.commit();
			connection.close();
			
		}catch(Exception e) {
			System.err.println("invalid");
		}
		
		return doctors;		
		
		
		
		
		
	}

	@Override
	public boolean removeDoctor(long id) {

		boolean status =false;
		try {
			java.sql.Connection connection=com.hospital.doctor.DBUtil.getConnection();
			String sql="delete from tempdoctor where id=?";
			java.sql.PreparedStatement preparedStatement=connection.prepareStatement(sql);
			preparedStatement.setLong(1,id);
			preparedStatement.execute();
			connection.commit();
			connection.close();
			 status=true;
		}catch (Exception e) {
			System.err.println("Invalid");
		}

		
		return status;	}

}
