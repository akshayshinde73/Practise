package com.hospital.doctor;

//AKSHAY SHINDE
public class DBUtil {

	public static java.sql.Connection getConnection(){
		java.sql.Connection connection=null;
		try {
			//step 1:Register your class 
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			//step 2:establish connection
			 connection=java.sql.DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","akshays2","shinde");
	
	  
		}catch(ClassNotFoundException cnfe) {
			cnfe.printStackTrace();
			//System.err.println(cnfe);
		}catch(java.sql.SQLException sqle) {
			//System.err.println(sqle);
			sqle.printStackTrace();

		}
		return connection;
	}
}
