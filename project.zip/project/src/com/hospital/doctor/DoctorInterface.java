package com.hospital.doctor;

//AKSHAY SHINDE

public interface DoctorInterface {
	
	public long addDoctor(String name,String speciality);
	public com.hospital.doctor.bean.Doctor showDoctorById(long id);
	public java.util.List<com.hospital.doctor.bean.Doctor>showAllDoctor();
	public boolean removeDoctor(long id);


}
