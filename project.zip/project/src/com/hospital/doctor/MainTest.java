
// AKSHAY SHINDE

package com.hospital.doctor;

import java.util.InputMismatchException;

import com.hospital.doctor.bean.Doctor;
public class MainTest {
	private static com.hospital.doctor.DoctorDoa doctoDoa=new com.hospital.doctor.DoctorDoa();

	private static java.util.Scanner in=new java.util.Scanner(System.in);
	private static  com.hospital.doctor.DoctorInterface doctorDoa=new com.hospital.doctor.DoctorDoa();
public static void main(String[] args) {
	
	
	int choice=0;
	do {
		
	System.out.println("1.Add doctor");
	System.out.println("2.show Doctor by Id");
	System.out.println("3.show all doctor");
	System.out.println("4.Remove Doctor");
	System.out.println("0.exit");
   int innerchoice=in.nextInt();
   
   switch(innerchoice) {
   case 0:  break;
   case 1: 	addDoctor(); break;
   case 2: 	getDoctorById();break;
   case 3:	getAllDoctor();break;
   case 4:	removeDoctor();break;
   //case 5:	removeEmployee();break;
	   
   }
   System.out.println("enter choice[0/1]");
       choice=in.nextInt();
	}while(choice!=0);
	
}

private static void removeDoctor() {

	
	System.out.println("Enter id");
	long id=in.nextLong();
	boolean status=doctorDoa.removeDoctor(id);
	if(status==true) {
	System.out.println("Record removed");
	}
}




private static void getAllDoctor() {
	
	
	java.util.List<com.hospital.doctor.bean.Doctor> doctors= doctorDoa.showAllDoctor();
	for(com.hospital.doctor.bean.Doctor doctor : doctors) {
		System.out.println(doctor.toString());
	}
}

private static void getDoctorById() {
try {
	System.out.print("Enter id ");
	Long id=in.nextLong();
	//Doctor doctor=com.hospital.showDoctorById(id);

	Doctor doctor=doctorDoa.showDoctorById(id);

	System.out.println(doctor);
}catch(InputMismatchException e) {
	System.err.println("invalid input");
}catch(Exception e) {
	System.err.println("invalid input");
}
}

private static void addDoctor() {

	System.out.print("Enter Name ");
	 in.nextLine();
	String name=in.nextLine();
	System.out.print("specialization");
	String specification=in.nextLine();	
	
   long id=doctorDoa.addDoctor(name, specification);
	   
	   System.out.println("Doctor added with id"+id);
	
	
}
}
